# Open the file in read mode
with open("M0.txt", "r") as file:
    
    # Read the entire file as a string
    file_content = file.read()
    print(file_content)
    with open("ext.txt", "w") as file:
        
       file.write(file_content)
    

    # Print the file contents

    