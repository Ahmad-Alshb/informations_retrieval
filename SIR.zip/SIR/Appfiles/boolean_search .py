from .models import Documentdata

def boolean_model_search(query):
    print("Boolean used")
    # Tokenize the query
    query_terms = query.lower().split()

    # Find documents containing all query terms
    results = []
    for document in Documentdata.objects.all():
        document_terms = document.content.lower().split()
        if all(term in document_terms for term in query_terms):
            results.append(document)

    return results
