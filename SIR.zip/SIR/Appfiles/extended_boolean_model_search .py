from .models import Documentdata

def extended_boolean_model_search(query):
    # Tokenize the query
    query_terms = query.lower().split()

    # Find documents containing at least one query term
    results = []
    for document in Documentdata.objects.all():
        document_terms = document.content.lower().split()
        if any(term in document_terms for term in query_terms):
            results.append(document)

    return results
